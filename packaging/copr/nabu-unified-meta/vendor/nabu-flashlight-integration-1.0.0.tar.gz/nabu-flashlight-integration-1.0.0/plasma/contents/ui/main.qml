import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasmoid
import org.kde.plasma.plasma5support as Plasma5Support

PlasmoidItem {
    id: root
    property bool torchOn: false
    property bool flashAvailable: true
    property int brightness: Plasmoid.configuration.brightness || 13
    property bool autoRotate: true
    property bool autoBrightness: true
    property bool lidAction: true
    property bool lidClosed: false
    property string usbDataRole: "unknown"
    property string usbPowerRole: "unknown"
    property bool usbAvailable: false

    function run(command) {
        executable.connectSource(command)
    }

    function refresh() {
        run("/usr/bin/nabu-flashlightctl status")
        run("LANG=C kscreen-doctor -o")
        run("busctl --user call org.kde.Solid.PowerManagement /org/kde/Solid/PowerManagement org.kde.Solid.PowerManagement isLidClosed")
        run("busctl --user call org.kde.Solid.PowerManagement /org/kde/Solid/PowerManagement/Actions/HandleButtonEvents org.kde.Solid.PowerManagement.Actions.HandleButtonEvents triggersLidAction")
        run("/usr/bin/nabu-usb-role status")
    }

    function selectedRole(output, key) {
        const match = output.match(new RegExp(key + "=[^\\n]*\\[([^\\]]+)\\]"))
        return match ? match[1] : "unknown"
    }

    function applyResult(source, data) {
        // kscreen-doctor colorizes its human-readable output even when LANG=C.
        // Strip SGR sequences before matching state labels.
        const output = String(data.stdout || "").replace(/\u001b\[[0-9;]*m/g, "").trim()
        const succeeded = data["exit code"] === 0
        if (source === "/usr/bin/nabu-flashlightctl status") {
            flashAvailable = succeeded
            if (succeeded) {
                torchOn = output.startsWith("on")
                const fields = output.split(/\s+/)
                if (torchOn && fields.length > 1 && !isNaN(Number(fields[1])))
                    brightness = Math.max(1, Math.min(100, Number(fields[1])))
            }
        } else if (source === "LANG=C kscreen-doctor -o" && succeeded) {
            autoRotate = output.includes("Auto Rotate Policy: always")
            autoBrightness = output.includes("Automatic brightness: supported, enabled")
        } else if (source.includes("isLidClosed") && succeeded) {
            lidClosed = output.endsWith("true")
        } else if (source.includes("triggersLidAction") && succeeded) {
            lidAction = output.endsWith("true")
        } else if (source === "/usr/bin/nabu-usb-role status") {
            usbAvailable = succeeded && output.includes("type=") && output.includes("dual")
            if (succeeded) {
                usbDataRole = selectedRole(output, "data")
                usbPowerRole = selectedRole(output, "power")
            }
        } else if (source !== "LANG=C kscreen-doctor -o") {
            refreshTimer.restart()
        }
    }

    toolTipMainText: qsTr("Tablet Control")
    toolTipSubText: torchOn ? qsTr("Flashlight on") : qsTr("Nabu hardware controls")
    Plasmoid.icon: torchOn ? "flashlight-on" : "input-tablet"
    Plasmoid.status: torchOn ? PlasmaCore.Types.ActiveStatus : PlasmaCore.Types.PassiveStatus

    Plasma5Support.DataSource {
        id: executable
        engine: "executable"
        onNewData: function(source, data) {
            root.applyResult(source, data)
            disconnectSource(source)
        }
    }

    Component.onCompleted: refresh()
    onExpandedChanged: function(expanded) {
        if (expanded)
            refresh()
    }

    Timer {
        id: refreshTimer
        interval: 3000
        running: root.expanded
        repeat: true
        onTriggered: root.refresh()
    }

    Timer {
        interval: 15000
        running: true
        repeat: true
        onTriggered: root.run("/usr/bin/nabu-flashlightctl status")
    }

    compactRepresentation: PlasmaComponents.ToolButton {
        icon.name: root.torchOn ? "flashlight-on" : "input-tablet"
        onClicked: root.expanded = !root.expanded
        Accessible.name: root.toolTipMainText
    }

    fullRepresentation: ColumnLayout {
        Layout.minimumWidth: Kirigami.Units.gridUnit * 20
        Layout.maximumWidth: Kirigami.Units.gridUnit * 28
        spacing: Kirigami.Units.largeSpacing

        Kirigami.Heading {
            text: qsTr("Tablet Control")
            level: 2
            Layout.fillWidth: true
        }

        Kirigami.FormLayout {
            Layout.fillWidth: true

            RowLayout {
                Kirigami.FormData.label: qsTr("Flashlight:")

                PlasmaComponents.Label {
                    text: root.torchOn ? qsTr("On") : qsTr("Off")
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.torchOn ? qsTr("Turn off") : qsTr("Turn on")
                    enabled: root.flashAvailable
                    onClicked: root.run("/usr/bin/nabu-flashlightctl "
                        + (root.torchOn ? "off" : "on " + root.brightness))
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("Torch brightness:")
                Layout.fillWidth: true

                PlasmaComponents.Slider {
                    id: brightnessSlider
                    Layout.fillWidth: true
                    from: 1
                    to: 100
                    stepSize: 1
                    value: root.brightness
                    enabled: root.flashAvailable
                    onMoved: root.brightness = Math.round(brightnessSlider.value)
                    onPressedChanged: function() {
                        if (!brightnessSlider.pressed) {
                            Plasmoid.configuration.brightness = root.brightness
                            if (root.torchOn)
                                root.run("/usr/bin/nabu-flashlightctl set " + root.brightness)
                        }
                    }
                    Accessible.name: qsTr("Safe torch brightness")
                    Accessible.description: root.brightness + "%"
                }

                PlasmaComponents.Label {
                    text: root.brightness + "%"
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("Auto rotate:")

                PlasmaComponents.Label {
                    text: root.autoRotate ? qsTr("Active") : qsTr("Inactive")
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.autoRotate ? qsTr("Disable") : qsTr("Enable")
                    onClicked: root.run("kscreen-doctor output.DSI-1.autoRotatePolicy."
                        + (root.autoRotate ? "never" : "always"))
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("Auto brightness:")

                PlasmaComponents.Label {
                    text: root.autoBrightness ? qsTr("Active") : qsTr("Inactive")
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.autoBrightness ? qsTr("Disable") : qsTr("Enable")
                    onClicked: root.run("kscreen-doctor output.DSI-1.autoBrightness."
                        + (root.autoBrightness ? "disable" : "enable"))
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("Magnetic cover:")

                PlasmaComponents.Label {
                    text: (root.lidClosed ? qsTr("Closed") : qsTr("Open")) + " · "
                        + (root.lidAction ? qsTr("Active") : qsTr("Inactive"))
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.lidAction ? qsTr("Disable") : qsTr("Enable")
                    onClicked: {
                        const action = root.lidAction ? "0" : "32"
                        root.run("kwriteconfig6 --file powerdevilrc --group AC --group SuspendAndShutdown --key LidAction " + action
                            + " && kwriteconfig6 --file powerdevilrc --group Battery --group SuspendAndShutdown --key LidAction " + action
                            + " && kwriteconfig6 --file powerdevilrc --group LowBattery --group SuspendAndShutdown --key LidAction " + action
                            + " && busctl --user call org.kde.Solid.PowerManagement /org/kde/Solid/PowerManagement org.kde.Solid.PowerManagement reparseConfiguration")
                    }
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("USB data role:")

                PlasmaComponents.Label {
                    text: root.usbDataRole
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.usbDataRole === "host" ? qsTr("Use device") : qsTr("Use host")
                    enabled: root.usbAvailable
                    onClicked: root.run("pkexec /usr/libexec/nabu-usb-role set data "
                        + (root.usbDataRole === "host" ? "device" : "host"))
                }
            }

            RowLayout {
                Kirigami.FormData.label: qsTr("USB power role:")

                PlasmaComponents.Label {
                    text: root.usbPowerRole
                    Layout.fillWidth: true
                }

                PlasmaComponents.Button {
                    text: root.usbPowerRole === "source" ? qsTr("Use sink") : qsTr("Supply power")
                    enabled: root.usbAvailable
                    onClicked: root.run("pkexec /usr/libexec/nabu-usb-role set power "
                        + (root.usbPowerRole === "source" ? "sink" : "source"))
                }
            }
        }

        PlasmaComponents.Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            opacity: 0.75
            text: qsTr("USB role swaps require authorization and may be rejected by the connected partner. Flashlight percentages stay inside the kernel torch-current limit.")
        }
    }
}
