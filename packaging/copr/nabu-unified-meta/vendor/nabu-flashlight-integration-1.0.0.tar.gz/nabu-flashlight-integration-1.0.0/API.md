# Nabu flashlight user API

Applications may call `nabu-flashlightctl` with `status`, `on [1-100]`,
`off`, `toggle [1-100]`, or `set 1-100`. Percent values are scaled only to
the kernel LED-class `max_brightness` value for the two fixed Nabu torch
channels. The helper cannot select another sysfs path and does not expose the
high-current camera strobe operation.

USB-C role status is available with `nabu-usb-role status`. Role changes use
`pkexec /usr/libexec/nabu-usb-role set data host|device` or
`pkexec /usr/libexec/nabu-usb-role set power source|sink`; the kernel TCPM
driver and the connected partner may reject a role swap.
