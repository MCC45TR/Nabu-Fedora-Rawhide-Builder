import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as QuickSettings from 'resource:///org/gnome/shell/ui/quickSettings.js';
import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const FLASHLIGHT = '/usr/libexec/nabu-flashlight';
const USB_ROLE = '/usr/libexec/nabu-usb-role';
const USB_GADGET = '/usr/libexec/nabu-usb-gadget';
const ACCESSORIES = '/usr/libexec/nabu-accessory-state';

function run(argv, callback) {
    try {
        const proc = Gio.Subprocess.new(argv,
            Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE);
        proc.communicate_utf8_async(null, null, (process, result) => {
            try {
                const [, stdout] = process.communicate_utf8_finish(result);
                callback(process.get_successful(), stdout.trim());
            } catch (_) {
                callback(false, '');
            }
        });
    } catch (_) {
        callback(false, '');
    }
}

function value(output, key, fallback = '') {
    return output.match(new RegExp(`(?:^|\\n)${key}=([^\\n]+)`))?.[1]?.trim() ?? fallback;
}

const FlashlightSlider = GObject.registerClass(
class FlashlightSlider extends QuickSettings.QuickSlider {
    _init(indicator) {
        super._init({
            iconName: 'display-brightness-symbolic',
            iconLabel: _('Flashlight brightness'),
        });
        this._indicator = indicator;
        this.slider.accessible_name = _('Flashlight brightness');
        this.slider.value = 0.13;
        this._changedId = this.slider.connect('notify::value', () => {
            this._indicator.queueFlashlightLevel(Math.max(1,
                Math.round(this.slider.value * 100)));
        });
    }

    setPercent(percent) {
        this.slider.block_signal_handler(this._changedId);
        this.slider.value = Math.max(1, percent) / 100;
        this.slider.unblock_signal_handler(this._changedId);
    }
});

const TabletIndicator = GObject.registerClass(
class TabletIndicator extends QuickSettings.SystemIndicator {
    _init() {
        super._init();
        this._flashlightOn = false;
        this._flashlightLevel = 13;
        this._levelTimeout = 0;
        this._powerSettings = null;
        this._settingsSignal = 0;
        this._buildItems();
        this.refresh();
    }

    _toggle(title, iconName, callback) {
        const item = new QuickSettings.QuickToggle({title, iconName, toggleMode: true});
        item.visible = false;
        item.connect('clicked', callback);
        this.quickSettingsItems.push(item);
        return item;
    }

    _buildItems() {
        this._flashlight = this._toggle(_('Flashlight'), 'flashlight-off-symbolic', () => {
            const command = this._flashlightOn
                ? [FLASHLIGHT, 'off']
                : [FLASHLIGHT, 'on', String(this._flashlightLevel)];
            this._flashlightOn = !this._flashlightOn;
            this._flashlight.checked = this._flashlightOn;
            run(command, () => this._refreshFlashlight());
        });
        this._flashlightSlider = new FlashlightSlider(this);
        this._flashlightSlider.visible = false;
        this.quickSettingsItems.push(this._flashlightSlider);

        this._autoBrightness = this._toggle(_('Automatic brightness'),
            'display-brightness-symbolic', () => {
                if (this._powerSettings)
                    this._powerSettings.set_boolean('ambient-enabled', this._autoBrightness.checked);
            });
        this._setupAutoBrightness();

        this._usbSharing = this._toggle(_('USB device sharing'),
            'network-wired-symbolic', () => {
                const mode = this._usbSharing.checked ? 'gadget' : 'off';
                run(['pkexec', USB_ROLE, 'set', 'mode', mode], () => this._refreshUsb());
            });
        this._usbData = this._toggle(_('USB data role'),
            'drive-removable-media-usb-symbolic', () => {
                const mode = this._usbData.checked ? 'host' : 'gadget';
                run(['pkexec', USB_ROLE, 'set', 'mode', mode], () => this._refreshUsb());
            });
        this._usbPower = this._toggle(_('USB power role'),
            'battery-symbolic', () => {
                const role = this._usbPower.checked ? 'source' : 'sink';
                run(['pkexec', USB_ROLE, 'set', 'power', role], () => this._refreshUsb());
            });

        this._pen = this._toggle(_('Xiaomi Smart Pen'), 'input-tablet-symbolic', () => {
            if (this._pen.checked && this._penAddress)
                run([ACCESSORIES, 'connect', this._penAddress], () => this._refreshAccessories());
        });
        this._keyboard = this._toggle(_('Pogo keyboard'), 'input-keyboard-symbolic', () => {});
        this._keyboard.toggleMode = false;
        this._keyboard.reactive = false;
    }

    _setupAutoBrightness() {
        // Do not duplicate a native GNOME implementation if Shell gains one.
        const shellQuickSettings = Main.panel.statusArea.quickSettings;
        if (shellQuickSettings._autoBrightness || shellQuickSettings._ambientBrightness)
            return;
        const source = Gio.SettingsSchemaSource.get_default();
        const schema = source?.lookup('org.gnome.settings-daemon.plugins.power', true);
        if (!schema?.has_key('ambient-enabled'))
            return;
        this._powerSettings = new Gio.Settings({settings_schema: schema});
        this._autoBrightness.visible = true;
        const sync = () => {
            this._autoBrightness.checked = this._powerSettings.get_boolean('ambient-enabled');
            this._autoBrightness.subtitle = this._autoBrightness.checked ? _('Active') : _('Inactive');
        };
        this._settingsSignal = this._powerSettings.connect('changed::ambient-enabled', sync);
        sync();
    }

    queueFlashlightLevel(percent) {
        this._flashlightLevel = percent;
        if (!this._flashlightOn)
            return;
        if (this._levelTimeout)
            GLib.source_remove(this._levelTimeout);
        this._levelTimeout = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 40, () => {
            this._levelTimeout = 0;
            run([FLASHLIGHT, 'set', String(this._flashlightLevel)], () => {});
            return GLib.SOURCE_REMOVE;
        });
    }

    _refreshFlashlight() {
        run([FLASHLIGHT, 'status'], (success, output) => {
            this._flashlight.visible = success;
            this._flashlightSlider.visible = success;
            if (!success)
                return;
            const fields = output.split(/\s+/);
            this._flashlightOn = fields[0] === 'on';
            const level = Number(fields[1]);
            if (Number.isFinite(level))
                this._flashlightLevel = level;
            this._flashlight.checked = this._flashlightOn;
            this._flashlight.subtitle = this._flashlightOn
                ? _('On at %1%').replace('%1', this._flashlightLevel) : _('Off');
            this._flashlight.iconName = this._flashlightOn
                ? 'flashlight-on-symbolic' : 'flashlight-off-symbolic';
            this._flashlightSlider.setPercent(this._flashlightLevel);
        });
    }

    _refreshUsb() {
        run([USB_ROLE, 'status'], (success, output) => {
            const available = success && output.includes('type=') && output.includes('dual');
            this._usbData.visible = available;
            this._usbPower.visible = available;
            if (!available)
                return;
            const dataRole = output.match(/data=[^\n]*\[([^\]]+)\]/)?.[1] ?? 'unknown';
            const powerRole = output.match(/power=[^\n]*\[([^\]]+)\]/)?.[1] ?? 'unknown';
            this._usbData.checked = dataRole === 'host';
            this._usbData.subtitle = dataRole === 'host' ? _('Host mode') : _('Device mode');
            this._usbPower.checked = powerRole === 'source';
            this._usbPower.subtitle = powerRole === 'source' ? _('Supplying power') : _('Power sink');
        });
        run([USB_GADGET, 'status'], (success, output) => {
            this._usbSharing.visible = success;
            this._usbSharing.checked = value(output, 'gadget', 'inactive') === 'active';
            this._usbSharing.subtitle = this._usbSharing.checked ? _('Active') : _('Inactive');
        });
    }

    _refreshAccessories() {
        run([ACCESSORIES, 'status'], (success, output) => {
            const paired = success && value(output, 'pen_paired', '0') === '1';
            const connected = success && value(output, 'pen_connected', '0') === '1';
            const battery = Number(value(output, 'pen_battery', '-1'));
            const charging = value(output, 'pen_charging', '0') === '1';
            this._penAddress = value(output, 'pen_address');
            this._pen.visible = paired;
            this._pen.checked = connected;
            this._pen.reactive = !connected;
            this._pen.title = paired ? value(output, 'pen_name', _('Xiaomi Smart Pen')) : _('Xiaomi Smart Pen');
            const penState = [connected ? _('Connected') : _('Paired')];
            if (battery >= 0)
                penState.push(_('Battery: %1%').replace('%1', battery));
            if (charging)
                penState.push(_('Charging'));
            this._pen.subtitle = penState.join(' · ');

            const attached = success && value(output, 'keyboard_attached', '0') === '1';
            this._keyboard.visible = attached;
            this._keyboard.subtitle = _('Attached');
        });
    }

    refresh() {
        this._refreshFlashlight();
        this._refreshUsb();
        this._refreshAccessories();
    }

    destroy() {
        if (this._levelTimeout)
            GLib.source_remove(this._levelTimeout);
        if (this._powerSettings && this._settingsSignal)
            this._powerSettings.disconnect(this._settingsSignal);
        this.quickSettingsItems.forEach(item => item.destroy());
        super.destroy();
    }
});

export default class NabuTabletControlsExtension extends Extension {
    enable() {
        this._indicator = new TabletIndicator();
        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator, 2);
        this._menuSignal = Main.panel.statusArea.quickSettings.menu.connect(
            'open-state-changed', (_menu, open) => {
                if (open)
                    this._indicator?.refresh();
            });
    }

    disable() {
        if (this._menuSignal)
            Main.panel.statusArea.quickSettings.menu.disconnect(this._menuSignal);
        this._menuSignal = 0;
        this._indicator?.destroy();
        this._indicator = null;
    }
}
