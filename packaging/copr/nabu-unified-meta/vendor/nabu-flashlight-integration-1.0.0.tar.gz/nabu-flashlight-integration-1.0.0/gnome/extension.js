import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as QuickSettings from 'resource:///org/gnome/shell/ui/quickSettings.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const FlashlightSlider = GObject.registerClass(
class FlashlightSlider extends QuickSettings.QuickSlider {
    constructor(indicator) {
        super({
            iconName: 'flashlight-on-symbolic',
            iconLabel: _('Flashlight brightness'),
        });
        this._indicator = indicator;
        this.slider.accessible_name = _('Flashlight brightness');
        this.slider.value = 0.13;
        this._changedId = this.slider.connect('notify::value', () => {
            const percent = Math.max(1, Math.round(this.slider.value * 100));
            if (this._indicator._enabled)
                this._indicator._run(`set ${percent}`);
        });
    }

    setPercent(percent) {
        this.slider.block_signal_handler(this._changedId);
        this.slider.value = Math.max(1, percent) / 100.0;
        this.slider.unblock_signal_handler(this._changedId);
    }
});

class FlashlightIndicator extends QuickSettings.SystemIndicator {
    constructor() {
        super();
        this._toggle = new QuickSettings.QuickToggle({
            title: _('Flashlight'),
            iconName: 'flashlight-off-symbolic',
            toggleMode: true,
        });
        this.quickSettingsItems.push(this._toggle);
        this._slider = new FlashlightSlider(this);
        this.quickSettingsItems.push(this._slider);
        this._enabled = false;
        this._toggle.connect('clicked', () => {
            const percent = Math.max(1, Math.round(this._slider.slider.value * 100));
            this._run(this._enabled ? 'off' : `on ${percent}`);
        });
        this._run('status');
    }

    _run(command) {
        const proc = Gio.Subprocess.new(
            ['/usr/libexec/nabu-flashlight', command],
            Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE);
        proc.communicate_utf8_async(null, null, (p, result) => {
            try {
                const [, stdout] = p.communicate_utf8_finish(result);
                const fields = stdout.trim().split(/\s+/);
                const enabled = fields[0] === 'on';
                const percent = fields.length > 1 ? Number(fields[1]) : 13;
                this._enabled = enabled;
                this._toggle.checked = enabled;
                this._toggle.iconName = enabled ? 'flashlight-on-symbolic' : 'flashlight-off-symbolic';
                this._toggle.reactive = p.get_successful();
                this._slider.reactive = p.get_successful();
                if (enabled && Number.isFinite(percent))
                    this._slider.setPercent(percent);
            } catch (_) {
                this._toggle.reactive = false;
            }
        });
    }

    destroy() {
        this.quickSettingsItems.forEach(item => item.destroy());
        super.destroy();
    }
}

export default class NabuFlashlightExtension extends Extension {
    enable() {
        this._indicator = new FlashlightIndicator();
        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator, 2);
    }

    disable() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
