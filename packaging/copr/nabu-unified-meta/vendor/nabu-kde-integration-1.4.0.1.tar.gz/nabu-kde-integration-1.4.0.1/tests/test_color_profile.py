#!/usr/bin/python3
"""Synthetic, redistributable tests for the QDCM-to-ICC conversion path."""

import importlib.machinery
import importlib.util
from pathlib import Path
import struct
import tempfile
import unittest
import xml.etree.ElementTree as ET


SCRIPT = Path(__file__).parents[1] / "kde" / "senemos-nabu-color-profile"
LOADER = importlib.machinery.SourceFileLoader("nabu_color_profile", str(SCRIPT))
SPEC = importlib.util.spec_from_loader(LOADER.name, LOADER)
MODULE = importlib.util.module_from_spec(SPEC)
LOADER.exec_module(MODULE)


def curve_payload(points, maximum, header):
    words = [header, points, 6] + [0] * (1024 * 3)
    for channel in range(3):
        offset = 3 + channel * 1024
        for index in range(points):
            words[offset + index] = round(index * maximum / (points - 1))
    return struct.pack(f"<{len(words)}I", *words)


def clut_payload():
    words = [0, 0, 0, 4913]
    for blue in range(17):
        for green in range(17):
            for red in range(17):
                words.extend((
                    red * 256, green * 256, blue * 256,
                    red * 256, green * 256, blue * 256,
                ))
    return struct.pack(f"<{len(words)}I", *words)


def add_feature(mode, feature_type, payload):
    feature = ET.SubElement(
        mode, "Feature",
        FeatureType=feature_type, Disable="false", DataSize=str(len(payload)),
    )
    feature.text = payload.hex().upper()


def write_fixture(path):
    root = ET.Element("Calib_Data")
    modes = ET.SubElement(root, "Disp_Modes", NumModes="2")
    for name, mode_id, gamut in (("hal_srgb", "3", "srgb"), ("hal_dci_p3", "36", "dcip3")):
        mode = ET.SubElement(
            modes, "Mode", Name=name, ModeID=mode_id,
            ColorGamut=gamut, DynamicRange="sdr",
        )
        add_feature(mode, "7", curve_payload(256, 4095, 262144))
        add_feature(mode, "3", clut_payload())
        add_feature(mode, "8", curve_payload(1024, 1023, 0))
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)


class ColorProfileTests(unittest.TestCase):
    def test_synthetic_qdcm_generates_kwin_compatible_profiles(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            source = directory / "qdcm_calib_data_xiaomi_36_02_0b_video_mode_dual_dsi_cphy_panel.xml"
            output = directory / "icc"
            write_fixture(source)
            MODULE.import_profiles(source, output)
            profiles = sorted(output.glob("*.icc"))
            self.assertEqual(len(profiles), 2)
            for profile in profiles:
                MODULE.validate_icc(profile, quiet=True)
                tags = MODULE.icc_tags(profile.read_bytes())
                self.assertEqual(tags["B2A0"][0:4], b"mBA ")
                self.assertEqual(tags["B2A1"][0:4], b"mBA ")


if __name__ == "__main__":
    unittest.main()
